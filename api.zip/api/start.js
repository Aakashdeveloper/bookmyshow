require('@babel/register')({})
module.exports = require('./src/app')